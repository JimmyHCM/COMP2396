public interface Command {
	public String execute(VendingMachine v, String[] cmdParts);
}
