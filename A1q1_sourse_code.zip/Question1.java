import java.io.*;

public class Question1 {
    public static int remainingBalance(BufferedReader reader) throws IOException {
        return 0;
    }

	public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int result = remainingBalance(reader);
        System.out.println("The remaining balance is " + result + ".");
	}
}