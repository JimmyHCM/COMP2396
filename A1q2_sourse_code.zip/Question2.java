import java.io.*;

public class Question2 {
    public static int minimumTime(BufferedReader reader) throws IOException {
        return 0;
    }

	public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int result = minimumTime(reader);
        System.out.println("The minimum time needed is " + result + ".");
	}
}